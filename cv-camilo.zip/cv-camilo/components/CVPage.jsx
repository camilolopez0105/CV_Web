import { cv } from "../data/cv";
import styles from "../styles/cv.module.css";

export default function CVPage() {
  return (
    <div className={styles.page}>
      <div className={styles.container}>

        {/* NAV */}
        <nav className={styles.nav}>
          <span className={styles.navLogo}>CAL</span>
          <div className={styles.navLinks}>
            <a href="#sobre-mi">sobre mí</a>
            <a href="#experiencia">experiencia</a>
            <a href="#proyectos">proyectos</a>
            <a href="#contacto">contacto</a>
          </div>
        </nav>

        {/* HERO */}
        <section className={styles.hero}>
          <p className={styles.heroTag}>{cv.title} · {cv.subtitle}</p>
          <h1 className={styles.heroName}>
            {cv.name.split(" ").slice(0, 2).join(" ")}{" "}
            <span className={styles.accent}>
              {cv.name.split(" ").slice(2).join(" ")}
            </span>
          </h1>
          <p className={styles.heroBio}>{cv.bio}</p>
        </section>

        {/* HABILIDADES */}
        <section className={styles.section} id="sobre-mi">
          <h2 className={styles.sectionLabel}>Habilidades</h2>
          <div className={styles.skillsGrid}>
            {cv.skills.map((skill) => (
              <span key={skill} className={styles.skillTag}>{skill}</span>
            ))}
          </div>
        </section>

        {/* EXPERIENCIA */}
        <section className={styles.section} id="experiencia">
          <h2 className={styles.sectionLabel}>Experiencia</h2>
          <div className={styles.expList}>
            {cv.experience.map((item, i) => (
              <div key={i} className={styles.expItem}>
                <div className={styles.expDot} />
                <div className={styles.expContent}>
                  <p className={styles.expRole}>{item.role}</p>
                  <p className={styles.expCompany}>{item.company}</p>
                  <p className={styles.expDate}>{item.date}</p>
                  <p className={styles.expDesc}>{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* PROYECTOS */}
        <section className={styles.section} id="proyectos">
          <h2 className={styles.sectionLabel}>Proyectos</h2>
          <div className={styles.projectsGrid}>
            {cv.projects.map((project, i) => (
              <div key={i} className={styles.projectCard}>
                <div className={styles.projectHeader}>
                  <p className={styles.projectName}>{project.name}</p>
                  {project.link && (
                    <a
                      href={project.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={styles.projectLink}
                      aria-label={`Ver ${project.name} en GitHub`}
                    >
                      ↗
                    </a>
                  )}
                </div>
                <p className={styles.projectDesc}>{project.description}</p>
                <div className={styles.projectTags}>
                  {project.tags.map((tag) => (
                    <span key={tag} className={styles.projectTag}>{tag}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* IDIOMAS */}
        <section className={styles.section}>
          <h2 className={styles.sectionLabel}>Idiomas</h2>
          <div className={styles.langRow}>
            {cv.languages.map((lang) => (
              <div key={lang.name} className={styles.langItem}>
                <p className={styles.langName}>{lang.name}</p>
                <p className={styles.langLevel}>{lang.level}</p>
                <div className={styles.langBar}>
                  <div
                    className={styles.langFill}
                    style={{ width: `${lang.bar}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* CONTACTO */}
        <section className={styles.section} id="contacto">
          <h2 className={styles.sectionLabel}>Contacto</h2>
          <div className={styles.contactGrid}>
            <a href={`mailto:${cv.contact.email}`} className={styles.contactItem}>
              <span className={styles.contactIcon}>✉</span>
              <span>{cv.contact.email}</span>
            </a>
            {cv.contact.linkedin && (
              <a
                href={cv.contact.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className={styles.contactItem}
              >
                <span className={styles.contactIcon}>in</span>
                <span>LinkedIn</span>
              </a>
            )}
            {cv.contact.github && (
              <a
                href={cv.contact.github}
                target="_blank"
                rel="noopener noreferrer"
                className={styles.contactItem}
              >
                <span className={styles.contactIcon}>gh</span>
                <span>GitHub</span>
              </a>
            )}
            <div className={styles.contactItem}>
              <span className={styles.contactIcon}>◎</span>
              <span>{cv.contact.location}</span>
            </div>
          </div>
        </section>

        <footer className={styles.footer}>
          <p>© {new Date().getFullYear()} {cv.name}</p>
        </footer>

      </div>
    </div>
  );
}
