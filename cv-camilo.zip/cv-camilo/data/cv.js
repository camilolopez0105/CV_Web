// ============================================================
//  ESTE ES EL ÚNICO ARCHIVO QUE NECESITAS EDITAR
//  Cambia los valores entre comillas con tu información real
// ============================================================

export const cv = {

  // --- HEADER ---
  name: "Camilo A. Lopez Restrepo",
  title: "Analista de Datos",           // tu título profesional
  subtitle: "UpgradeHub · en progreso", // subtítulo o empresa actual

  // --- SOBRE MÍ ---
  bio: "Transformando datos en decisiones. Apasionado por encontrar el patrón detrás del ruido y comunicarlo con claridad. Actualmente formándome como analista de datos con enfoque en visualización y machine learning.",

  // --- HABILIDADES ---
  // Agrega o quita los que quieras
  skills: [
    "Python",
    "SQL",
    "Power BI",
    "Excel avanzado",
    "Pandas",
    "NumPy",
    "Visualización de datos",
    "Machine Learning",
    "Git",
    "Estadística",
  ],

  // --- EXPERIENCIA ---
  // Duplica un bloque {} para agregar más entradas
  experience: [
    {
      role: "Analista de Datos (en formación)",
      company: "UpgradeHub",
      date: "2024 – Presente",
      description: "Breve descripción de lo que haces o aprendes aquí. Una o dos frases.",
    },
    {
      role: "Tu rol anterior",
      company: "Empresa anterior",
      date: "2022 – 2024",
      description: "Descripción breve de tus responsabilidades y logros principales.",
    },
    {
      role: "Otro rol o voluntariado",
      company: "Organización",
      date: "2020 – 2022",
      description: "Puedes usar esto para trabajo freelance, proyectos personales o voluntariado.",
    },
  ],

  // --- PROYECTOS ---
  // Cada proyecto tiene nombre, descripción y un link opcional
  projects: [
    {
      name: "Dashboard de ventas",
      description: "Análisis y visualización de KPIs con Power BI. Describe brevemente el impacto o los datos usados.",
      link: "https://github.com/tu-usuario/proyecto-1", // pon "" si no tienes link
      tags: ["Power BI", "SQL"],
    },
    {
      name: "Análisis predictivo",
      description: "Modelo de clasificación con Python y scikit-learn. Describe el dataset y el resultado.",
      link: "https://github.com/tu-usuario/proyecto-2",
      tags: ["Python", "scikit-learn"],
    },
    {
      name: "Proyecto 3",
      description: "Descripción de tu tercer proyecto destacado. Qué problema resolviste y cómo.",
      link: "",
      tags: ["Pandas", "Matplotlib"],
    },
    {
      name: "Proyecto 4",
      description: "Otro proyecto que quieras mostrar. Puedes eliminarlo si no tienes cuatro.",
      link: "",
      tags: ["SQL", "Excel"],
    },
  ],

  // --- IDIOMAS ---
  // level va de 0 a 100 (para la barra visual)
  languages: [
    { name: "Español", level: "Nativo", bar: 100 },
    { name: "Inglés",  level: "Intermedio B1", bar: 55 },
    // { name: "Otro idioma", level: "Básico", bar: 25 },
  ],

  // --- CONTACTO ---
  contact: {
    email: "tu@email.com",
    linkedin: "https://linkedin.com/in/tu-usuario",  // URL completa
    github: "https://github.com/tu-usuario",          // URL completa
    location: "Colombia",                             // ciudad o país
  },
};
