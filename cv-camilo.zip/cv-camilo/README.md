# CV Online — Camilo A. Lopez Restrepo

CV personal minimalista construido con Next.js, diseño negro y cyan.

---

## ✏️ Cómo editar tu información

**Solo necesitas editar un archivo:** `data/cv.js`

Abre ese archivo y reemplaza los textos entre comillas con tu información real.
Los comentarios dentro del archivo te guían en cada sección.

---

## 🚀 Cómo correrlo en tu computador

Necesitas tener [Node.js](https://nodejs.org/) instalado (versión 18 o superior).

```bash
# 1. Instalar dependencias (solo la primera vez)
npm install

# 2. Correr en modo desarrollo
npm run dev
```

Abre http://localhost:3000 en tu navegador.

---

## 🌐 Cómo publicarlo en GitHub Pages

### Primera vez:

1. Sube este proyecto a un repositorio de GitHub
2. Ve a **Settings → Pages**
3. En "Source" selecciona **GitHub Actions**
4. Listo — cada vez que hagas `git push`, se despliega automáticamente

### Tu URL será:
```
https://TU-USUARIO.github.io/NOMBRE-DEL-REPOSITORIO
```

---

## 📁 Estructura del proyecto

```
cv-camilo/
├── data/
│   └── cv.js          ← ✏️  EDITA AQUÍ tu información
├── components/
│   └── CVPage.jsx     ← estructura HTML del CV
├── pages/
│   ├── _app.js        ← configuración de Next.js
│   └── index.js       ← página principal
├── styles/
│   ├── cv.module.css  ← todo el diseño visual
│   └── globals.css    ← estilos base
└── .github/
    └── workflows/
        └── deploy.yml ← despliegue automático a GitHub Pages
```

---

Hecho con Next.js 14 · Desplegado en GitHub Pages
