import "../styles/globals.css";
import Head from "next/head";
import { cv } from "../data/cv";

export default function App({ Component, pageProps }) {
  return (
    <>
      <Head>
        <title>{cv.name} — {cv.title}</title>
        <meta name="description" content={cv.bio} />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta property="og:title" content={`${cv.name} — ${cv.title}`} />
        <meta property="og:description" content={cv.bio} />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <Component {...pageProps} />
    </>
  );
}
