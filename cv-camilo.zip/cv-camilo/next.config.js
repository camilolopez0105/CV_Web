/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "export",    // genera archivos estáticos para GitHub Pages
  trailingSlash: true, // necesario para que funcione en GitHub Pages
  images: {
    unoptimized: true, // requerido con output: export
  },
};

module.exports = nextConfig;
